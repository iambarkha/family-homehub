package com.aab.homehub.homehub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomehubApplicationTests {

	@Test
	void contextLoads() {
	}

}
